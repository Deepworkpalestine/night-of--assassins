# Night Of Assassins

Flutter source for the Arabic social deduction game.

## Build APK

GitHub Actions builds an Android release APK when you push to `main` or manually run the workflow from the Actions tab. The Android platform folder is generated in CI. Download the `Night-Of-Assassins-APK` artifact from a successful workflow run.
