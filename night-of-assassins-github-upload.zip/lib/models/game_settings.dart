import 'dart:math';

class MafiaGameSettings {
  final int playerCount;
  final int mafiaCount;
  final int killsPerNight;
  final bool hasDoctor;
  final bool hasDetective;
  final bool hasGodfather;
  final bool hasBodyguard;
  final bool hasSpy;
  final bool hasHunter;
  final bool hasJester;
  final bool hasGambler;
  final bool revealEliminatedRole;
  final bool showVoteDetails;

  const MafiaGameSettings({
    this.playerCount = 6,
    this.mafiaCount = 1,
    this.killsPerNight = 1,
    this.hasDoctor = true,
    this.hasDetective = true,
    this.hasGodfather = false,
    this.hasBodyguard = false,
    this.hasSpy = false,
    this.hasHunter = false,
    this.hasJester = false,
    this.hasGambler = false,
    this.revealEliminatedRole = true,
    this.showVoteDetails = true,
  });

  static int maxMafiaForPlayerCount(int count) {
    return max(1, (count - 1) ~/ 3);
  }

  int get totalMafiaRoles {
    return mafiaCount;
  }

  int get selectedSpecialMafiaCount {
    return (hasGodfather ? 1 : 0) + (hasSpy ? 1 : 0);
  }

  int get selectedNonMafiaSpecialCount {
    return (hasDoctor ? 1 : 0) +
        (hasDetective ? 1 : 0) +
        (hasBodyguard ? 1 : 0) +
        (hasHunter ? 1 : 0) +
        (hasJester ? 1 : 0) +
        (hasGambler ? 1 : 0);
  }

  int get minimumRequiredPlayers {
    final effectiveMafia = max(mafiaCount, selectedSpecialMafiaCount);
    return max(4, effectiveMafia * 2 + selectedNonMafiaSpecialCount + 1);
  }

  MafiaGameSettings copyWith({
    int? playerCount,
    int? mafiaCount,
    int? killsPerNight,
    bool? hasDoctor,
    bool? hasDetective,
    bool? hasGodfather,
    bool? hasBodyguard,
    bool? hasSpy,
    bool? hasHunter,
    bool? hasJester,
    bool? hasGambler,
    bool? revealEliminatedRole,
    bool? showVoteDetails,
  }) {
    final newPlayerCount = playerCount ?? this.playerCount;
    final maxMafia = maxMafiaForPlayerCount(newPlayerCount);
    final rawMafia = mafiaCount ?? this.mafiaCount;
    final clampedMafia = rawMafia.clamp(1, maxMafia);

    return MafiaGameSettings(
      playerCount: newPlayerCount,
      mafiaCount: clampedMafia,
      killsPerNight: (killsPerNight ?? this.killsPerNight).clamp(1, clampedMafia),
      hasDoctor: hasDoctor ?? this.hasDoctor,
      hasDetective: hasDetective ?? this.hasDetective,
      hasGodfather: hasGodfather ?? this.hasGodfather,
      hasBodyguard: hasBodyguard ?? this.hasBodyguard,
      hasSpy: hasSpy ?? this.hasSpy,
      hasHunter: hasHunter ?? this.hasHunter,
      hasJester: hasJester ?? this.hasJester,
      hasGambler: hasGambler ?? this.hasGambler,
      revealEliminatedRole: revealEliminatedRole ?? this.revealEliminatedRole,
      showVoteDetails: showVoteDetails ?? this.showVoteDetails,
    );
  }
}
