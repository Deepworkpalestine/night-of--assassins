import 'package:flutter/material.dart';

enum RoleTeam {
  citizens,
  mafia,
  independent,
}

enum MafiaRole {
  citizen,
  mafia,
  doctor,
  detective,
  godfather,
  bodyguard,
  spy,
  hunter,
  jester,
  gambler,
}

class MafiaRoleInfo {
  final MafiaRole role;
  final String nameAr;
  final String shortDesc;
  final String fullDesc;
  final RoleTeam team;
  final String cardLetter;
  final IconData icon;
  final Color color;

  const MafiaRoleInfo({
    required this.role,
    required this.nameAr,
    required this.shortDesc,
    required this.fullDesc,
    required this.team,
    required this.cardLetter,
    required this.icon,
    required this.color,
  });

  bool get isCitizenBehaviorInNight =>
      role == MafiaRole.citizen ||
      role == MafiaRole.hunter ||
      role == MafiaRole.jester;

  static const Map<MafiaRole, MafiaRoleInfo> roles = {
    MafiaRole.citizen: MafiaRoleInfo(
      role: MafiaRole.citizen,
      nameAr: 'المواطن',
      shortDesc: 'يحاول اكتشاف المغتالين من خلال النقاش والتصويت',
      fullDesc:
          'ينتمي لفريق المواطنين الصالحين. ليس لديه قدرة ليلية خاصة، وفي الليل يختار اسمه من القائمة كتمويه عند تمرير الجوال حتى لا يُكشف من يملك الأدوار الخاصة. يفوز بطرد جميع أعضاء المافيا.',
      team: RoleTeam.citizens,
      cardLetter: 'C',
      icon: Icons.person_outline,
      color: Color(0xFF4CAF50),
    ),
    MafiaRole.mafia: MafiaRoleInfo(
      role: MafiaRole.mafia,
      nameAr: 'المافيا',
      shortDesc: 'يختار لاعباً لقتله كل ليلة ويخفي هويته نهاراً',
      fullDesc:
          'ينتمي لفريق المافيا (المغتالين). يختار ضحية لقتلها كل ليلة بالتنسيق مع زملائه، ويحاول توجيه الشكوك نحو المواطنين في النهار. يفوز إذا تساوى عدد المافيا الأحياء مع عدد غير المافيا.',
      team: RoleTeam.mafia,
      cardLetter: 'M',
      icon: Icons.person_off_outlined,
      color: Color(0xFFD32F2F),
    ),
    MafiaRole.doctor: MafiaRoleInfo(
      role: MafiaRole.doctor,
      nameAr: 'الدكتور',
      shortDesc: 'يحمي لاعباً من القتل كل ليلة',
      fullDesc:
          'ينتمي لفريق المواطنين الصالحين. يختار لاعباً واحداً كل ليلة لحمايته من القتل (ويمكنه حماية نفسه)، لكن لا يمكنه حماية نفس اللاعب ليلتين متتاليتين.',
      team: RoleTeam.citizens,
      cardLetter: 'D',
      icon: Icons.medical_services_outlined,
      color: Color(0xFF26A69A),
    ),
    MafiaRole.detective: MafiaRoleInfo(
      role: MafiaRole.detective,
      nameAr: 'المحقق',
      shortDesc: 'يكشف هوية لاعب كل ليلة',
      fullDesc:
          'ينتمي لفريق المواطنين الصالحين. يتحقق كل ليلة من هوية لاعب واحد ليعرف ما إذا كان من فريق المافيا أم لا. تنبيه: العراب يخدع المحقق في المرة الأولى فيظهر له أنه ليس مافيا.',
      team: RoleTeam.citizens,
      cardLetter: 'I',
      icon: Icons.manage_search_rounded,
      color: Color(0xFF42A5F5),
    ),
    MafiaRole.godfather: MafiaRoleInfo(
      role: MafiaRole.godfather,
      nameAr: 'العراب',
      shortDesc: 'قائد المافيا يخدع المحقق',
      fullDesc:
          'قائد فريق المافيا. يشارك في القتل الليلي مع المافيا، ويتميز بأنه يخدع المحقق في محاولة التحقيق الأولى عنه فيظهر للمحقق على أنه "ليس مافيا"، ولا يُكشف إلا إذا حقق معه المحقق للمرة الثانية.',
      team: RoleTeam.mafia,
      cardLetter: 'G',
      icon: Icons.workspace_premium_outlined,
      color: Color(0xFFB71C1C),
    ),
    MafiaRole.bodyguard: MafiaRoleInfo(
      role: MafiaRole.bodyguard,
      nameAr: 'الحارس',
      shortDesc: 'يحمي لاعباً ويموت بدلاً عنه',
      fullDesc:
          'ينتمي لفريق المواطنين الصالحين. يختار كل ليلة لاعباً لحمايته من هجوم المافيا (ولا يمكنه حماية نفس اللاعب ليلتين متتاليتين). إذا استهدفت المافيا ذلك اللاعب ولم يحمه الدكتور، يضحي الحارس بنفسه ويموت بدلاً عنه.',
      team: RoleTeam.citizens,
      cardLetter: 'B',
      icon: Icons.shield_outlined,
      color: Color(0xFF5C6BC0),
    ),
    MafiaRole.spy: MafiaRoleInfo(
      role: MafiaRole.spy,
      nameAr: 'الجاسوس',
      shortDesc: 'يقتل أو يتجسس كل ليلة لصالح المافيا',
      fullDesc:
          'ينتمي لفريق المافيا. في كل ليلة يختار مهمة واحدة فقط: إما المشاركة في القتل أو التجسس على أي لاعب لكشف دوره الحقيقي بالكامل (مثلاً يعرف من هو الدكتور أو المحقق). لا يمكنه القتل والتجسس في الليلة نفسها.',
      team: RoleTeam.mafia,
      cardLetter: 'S',
      icon: Icons.visibility_outlined,
      color: Color(0xFF8E24AA),
    ),
    MafiaRole.hunter: MafiaRoleInfo(
      role: MafiaRole.hunter,
      nameAr: 'الصياد',
      shortDesc: 'ينتقم عند إقصائه بالتصويت',
      fullDesc:
          'ينتمي لفريق المواطنين الصالحين. في الليل يتصرف كمواطن عادي، ولكن إذا تم التصويت لإقصائه في مرحلة النهار، يمكنه الانتقام فوراً بإطلاق النار على لاعب واحد ليقصيه معه قبل مغادرة اللعبة.',
      team: RoleTeam.citizens,
      cardLetter: 'H',
      icon: Icons.gps_fixed_rounded,
      color: Color(0xFFFF7043),
    ),
    MafiaRole.jester: MafiaRoleInfo(
      role: MafiaRole.jester,
      nameAr: 'المهرج',
      shortDesc: 'يفوز إذا تم إقصاؤه بالتصويت',
      fullDesc:
          'دور مستقل (محايد) لا ينتمي للمواطنين ولا للمافيا. هدفه الوحيد هو إثارة الشبهات حول نفسه لكي يصوّت اللاعبون على طرده في النهار. إذا تم إقصاؤه بالتصويت يفوز باللعبة فوراً! (إذا فحصه المحقق يظهر له أنه ليس مافيا).',
      team: RoleTeam.independent,
      cardLetter: 'J',
      icon: Icons.theater_comedy_outlined,
      color: Color(0xFFFFCA28),
    ),
    MafiaRole.gambler: MafiaRoleInfo(
      role: MafiaRole.gambler,
      nameAr: 'المراهن',
      shortDesc: 'يراهن على إقصاء لاعب بالتصويت',
      fullDesc:
          'دور مستقل (محايد) لا ينتمي للمواطنين ولا للمافيا. في الليلة الأولى فقط يختار لاعباً يراهن على أنه سيُقصى بالتصويت النهاري خلال اللعبة. إذا تم التصويت لإقصاء ذلك اللاعب في أي جولة، يفوز المراهن! (إذا فحصه المحقق يظهر له أنه ليس مافيا).',
      team: RoleTeam.independent,
      cardLetter: 'W',
      icon: Icons.casino_outlined,
      color: Color(0xFFAB47BC),
    ),
  };

  static MafiaRoleInfo of(MafiaRole role) => roles[role]!;
}
