import 'package:flutter/material.dart';
import '../widgets/gothic_background.dart';

class ContactScreen extends StatefulWidget {
  const ContactScreen({super.key});

  @override
  State<ContactScreen> createState() => _ContactScreenState();
}

class _ContactScreenState extends State<ContactScreen> {
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _msgCtrl = TextEditingController();

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _msgCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GothicBackground(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: const Text('تواصل معنا'),
      ),
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text(
            'نحن نقدر رأيك! شاركنا اقتراحاتك أو ملاحظاتك لتحسين لعبة ليلة المغتالين.',
            style: TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _nameCtrl,
            decoration: const InputDecoration(
              labelText: 'الاسم',
              filled: true,
              fillColor: Color(0xFF21090E),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _emailCtrl,
            decoration: const InputDecoration(
              labelText: 'البريد الإلكتروني',
              filled: true,
              fillColor: Color(0xFF21090E),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _msgCtrl,
            maxLines: 5,
            decoration: const InputDecoration(
              labelText: 'اقتراحات أو ملاحظات',
              filled: true,
              fillColor: Color(0xFF21090E),
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 52,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFD32F2F),
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('تم إرسال رسالتك بنجاح!')),
                );
                Navigator.pop(context);
              },
              child: const Text('إرسال'),
            ),
          ),
        ],
      ),
    );
  }
}
