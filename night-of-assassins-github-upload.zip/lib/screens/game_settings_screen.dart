import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/game_settings.dart';
import '../models/mafia_role.dart';
import '../providers/app_providers.dart';
import '../widgets/gothic_background.dart';
import 'player_entry_screen.dart';

class GameSettingsScreen extends ConsumerStatefulWidget {
  const GameSettingsScreen({super.key});

  @override
  ConsumerState<GameSettingsScreen> createState() => _GameSettingsScreenState();
}

class _GameSettingsScreenState extends ConsumerState<GameSettingsScreen> {
  bool _showExtendedPlayers = false;

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(mafiaSettingsProvider);
    final notifier = ref.read(mafiaSettingsProvider.notifier);
    final maxMafia = MafiaGameSettings.maxMafiaForPlayerCount(settings.playerCount);

    return GothicBackground(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: const Text(
          'إعدادات اللعبة',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
      ),
      child: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
              children: [
                const Text(
                  'عدد اللاعبين',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                _buildPlayerCountGrid(
                  range: List.generate(9, (i) => i + 4),
                  selected: settings.playerCount,
                  onSelect: notifier.setPlayerCount,
                ),
                const SizedBox(height: 8),
                Center(
                  child: TextButton.icon(
                    onPressed: () {
                      setState(() {
                        _showExtendedPlayers = !_showExtendedPlayers;
                      });
                    },
                    icon: Icon(
                      _showExtendedPlayers
                          ? Icons.keyboard_arrow_up
                          : Icons.keyboard_arrow_down,
                      color: Colors.white70,
                    ),
                    label: Text(
                      _showExtendedPlayers ? 'إخفاء' : 'إظهار المزيد (13 - 50)',
                      style: const TextStyle(color: Colors.white70),
                    ),
                  ),
                ),
                if (_showExtendedPlayers)
                  _buildPlayerCountGrid(
                    range: List.generate(38, (i) => i + 13),
                    selected: settings.playerCount,
                    onSelect: notifier.setPlayerCount,
                  ),
                const SizedBox(height: 20),
                const Text(
                  'عدد المافيا',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: List.generate(maxMafia, (i) => i + 1).map((mCount) {
                    final isSelected = settings.mafiaCount == mCount;
                    return ChoiceChip(
                      label: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                        child: Text(
                          '$mCount',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: isSelected ? Colors.white : Colors.white70,
                          ),
                        ),
                      ),
                      selected: isSelected,
                      selectedColor: const Color(0xFFD32F2F),
                      backgroundColor: const Color(0xFF240B10),
                      onSelected: (_) => notifier.setMafiaCount(mCount),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 20),
                const Text(
                  'الأدوار الخاصة (جميعها مفتوحة مجاناً)',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 0.78,
                  children: [
                    _buildRoleCard(
                      role: MafiaRole.doctor,
                      value: settings.hasDoctor,
                      onChanged: notifier.toggleDoctor,
                    ),
                    _buildRoleCard(
                      role: MafiaRole.detective,
                      value: settings.hasDetective,
                      onChanged: notifier.toggleDetective,
                    ),
                    _buildRoleCard(
                      role: MafiaRole.godfather,
                      value: settings.hasGodfather,
                      onChanged: notifier.toggleGodfather,
                    ),
                    _buildRoleCard(
                      role: MafiaRole.bodyguard,
                      value: settings.hasBodyguard,
                      onChanged: notifier.toggleBodyguard,
                    ),
                    _buildRoleCard(
                      role: MafiaRole.spy,
                      value: settings.hasSpy,
                      onChanged: notifier.toggleSpy,
                    ),
                    _buildRoleCard(
                      role: MafiaRole.hunter,
                      value: settings.hasHunter,
                      onChanged: notifier.toggleHunter,
                    ),
                    _buildRoleCard(
                      role: MafiaRole.jester,
                      value: settings.hasJester,
                      onChanged: notifier.toggleJester,
                    ),
                    _buildRoleCard(
                      role: MafiaRole.gambler,
                      value: settings.hasGambler,
                      onChanged: notifier.toggleGambler,
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                SwitchListTile(
                  title: const Text('كشف دور المُقصى'),
                  subtitle: const Text('عرض دور اللاعب عند إقصائه بالتصويت'),
                  activeColor: const Color(0xFFD32F2F),
                  value: settings.revealEliminatedRole,
                  onChanged: notifier.toggleRevealEliminatedRole,
                ),
                SwitchListTile(
                  title: const Text('إظهار التصويتات'),
                  subtitle: const Text('عرض تفاصيل من صوّت لمن بعد التصويت'),
                  activeColor: const Color(0xFFD32F2F),
                  value: settings.showVoteDetails,
                  onChanged: notifier.toggleShowVoteDetails,
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFD32F2F),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                onPressed: () {
                  if (settings.playerCount < settings.minimumRequiredPlayers) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          'تحتاج ${settings.minimumRequiredPlayers} لاعبين على الأقل مع هذه الإعدادات',
                        ),
                      ),
                    );
                    return;
                  }
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const PlayerEntryScreen()),
                  );
                },
                child: const Text(
                  'التالي',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlayerCountGrid({
    required List<int> range,
    required int selected,
    required ValueChanged<int> onSelect,
  }) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFF1F0A0E),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white12),
      ),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        alignment: WrapAlignment.center,
        children: range.map((num) {
          final isSelected = selected == num;
          return GestureDetector(
            onTap: () => onSelect(num),
            child: Container(
              width: 42,
              height: 46,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: isSelected ? const Color(0xFFD32F2F) : const Color(0xFF2B1015),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isSelected ? Colors.redAccent : Colors.white24,
                ),
              ),
              child: Text(
                '$num',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: isSelected ? Colors.white : Colors.white70,
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildRoleCard({
    required MafiaRole role,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    final info = MafiaRoleInfo.of(role);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: value ? const Color(0xFF330D13) : const Color(0xFF1C090D),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: value ? const Color(0xFFD32F2F) : Colors.white12,
          width: 1.5,
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: info.team == RoleTeam.citizens
                      ? Colors.green.withOpacity(0.2)
                      : info.team == RoleTeam.mafia
                          ? Colors.red.withOpacity(0.2)
                          : Colors.amber.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  info.team == RoleTeam.citizens
                      ? 'مواطنون'
                      : info.team == RoleTeam.mafia
                          ? 'مافيا'
                          : 'مستقل',
                  style: TextStyle(
                    fontSize: 11,
                    color: info.team == RoleTeam.citizens
                        ? Colors.greenAccent
                        : info.team == RoleTeam.mafia
                            ? Colors.redAccent
                            : Colors.amberAccent,
                  ),
                ),
              ),
              IconButton(
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
                icon: const Icon(Icons.help_outline, size: 20, color: Colors.white54),
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                      backgroundColor: const Color(0xFF240B10),
                      title: Text(info.nameAr),
                      content: Text(info.fullDesc),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('فهمت'),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ],
          ),
          const Spacer(),
          CircleAvatar(
            radius: 30,
            backgroundColor: info.color.withOpacity(0.2),
            child: Icon(info.icon, size: 34, color: info.color),
          ),
          const SizedBox(height: 8),
          Text(
            info.nameAr,
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 4),
          Text(
            info.shortDesc,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 11, color: Colors.white60),
          ),
          const Spacer(),
          Switch(
            value: value,
            activeColor: const Color(0xFFD32F2F),
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}
