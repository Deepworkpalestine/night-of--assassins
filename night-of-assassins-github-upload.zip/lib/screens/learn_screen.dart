import 'package:flutter/material.dart';
import '../models/mafia_role.dart';
import '../widgets/gothic_background.dart';

class LearnScreen extends StatelessWidget {
  const LearnScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return GothicBackground(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: const Text('شرح اللعبة والأدوار'),
      ),
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text(
            'فِرَق اللعبة وشروط الفوز',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            '• المواطنون الصالحون: يفوزون عند طرد جميع أعضاء المافيا.
'
            '• فريق المافيا (المغتالون): يفوزون إذا تساوى عددهم مع عدد بقية اللاعبين الأحياء.
'
            '• الأدوار المستقلة (المهرج والمراهن): يلعبون لمصلحتهم الشخصية ولهم شروط فوز مستقلة.',
            style: TextStyle(color: Colors.white70, height: 1.5),
          ),
          const SizedBox(height: 20),
          const Text(
            'جميع الأدوار في ليلة المغتالين',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          ...MafiaRoleInfo.roles.values.map((info) {
            return Card(
              color: const Color(0xFF22090E),
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: info.color.withOpacity(0.2),
                  child: Icon(info.icon, color: info.color),
                ),
                title: Text(
                  info.nameAr,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: info.color,
                  ),
                ),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(info.fullDesc),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}
