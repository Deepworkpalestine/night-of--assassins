import 'dart:math';
import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../models/game_state.dart';
import '../models/mafia_role.dart';
import '../models/player.dart';
import '../providers/app_providers.dart';
import '../widgets/gothic_background.dart';
import '../widgets/hold_to_reveal_card.dart';

class MafiaGameScreen extends ConsumerStatefulWidget {
  const MafiaGameScreen({super.key});

  @override
  ConsumerState<MafiaGameScreen> createState() => _MafiaGameScreenState();
}

class _MafiaGameScreenState extends ConsumerState<MafiaGameScreen> {
  late ConfettiController _confettiController;
  bool _hasRevealedCurrentRole = false;

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
    _confettiController =
        ConfettiController(duration: const Duration(seconds: 4));
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    _confettiController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(mafiaGameProvider);
    final settings = ref.watch(mafiaSettingsProvider);
    final notifier = ref.read(mafiaGameProvider.notifier);

    if (state.phase == GamePhase.gameOver) {
      _confettiController.play();
    }

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        final shouldExit = await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            backgroundColor: const Color(0xFF240B10),
            title: const Text('الخروج من اللعبة؟'),
            content: const Text('سيتم إنهاء اللعبة الحالية'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('متابعة'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text(
                  'الخروج',
                  style: TextStyle(color: Colors.redAccent),
                ),
              ),
            ],
          ),
        );
        if (shouldExit == true && context.mounted) {
          Navigator.pop(context);
        }
      },
      child: GothicBackground(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          title: Text('الجولة ${state.currentRound}'),
        ),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: _buildPhaseContent(context, state, settings, notifier),
        ),
      ),
    );
  }

  Widget _buildPhaseContent(
    BuildContext context,
    MafiaGameState state,
    dynamic settings,
    dynamic notifier,
  ) {
    switch (state.phase) {
      case GamePhase.seatingArrangement:
        return _buildSeatingArrangement(state, notifier);
      case GamePhase.roleDistribution:
        return _buildRoleDistribution(state, notifier);
      case GamePhase.nightAction:
        return _buildNightAction(state, notifier);
      case GamePhase.nightResults:
        return _buildNightResults(state, notifier);
      case GamePhase.discussion:
        return _buildDiscussion(state, notifier);
      case GamePhase.voting:
        return _buildVoting(state, notifier);
      case GamePhase.voteResult:
        return _buildVoteResult(state, settings, notifier);
      case GamePhase.hunterRevenge:
        return _buildHunterRevenge(state, notifier);
      case GamePhase.gameOver:
        return _buildGameOver(state);
    }
  }

  Widget _buildSeatingArrangement(MafiaGameState state, dynamic notifier) {
    final count = state.players.length;
    return Column(
      children: [
        const Text(
          'ترتيب الجلسة',
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        const Text(
          'اجلسوا بشكل دائري بهالترتيب عشان يسهل تمرير الجوال',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white70, fontSize: 15),
        ),
        Expanded(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final radius =
                  min(constraints.maxWidth, constraints.maxHeight) * 0.36;
              final center = Offset(
                constraints.maxWidth / 2,
                constraints.maxHeight / 2,
              );
              return Stack(
                children: [
                  Center(
                    child: Container(
                      width: radius * 1.4,
                      height: radius * 1.4,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white24, width: 2),
                        color: const Color(0xFF21090E),
                      ),
                      alignment: Alignment.center,
                      child: const Text(
                        'طاولة اللعب',
                        style: TextStyle(color: Colors.white54),
                      ),
                    ),
                  ),
                  ...List.generate(count, (i) {
                    final angle = (2 * pi * i / count) - (pi / 2);
                    final x = center.dx + radius * cos(angle) - 42;
                    final y = center.dy + radius * sin(angle) - 22;
                    return Positioned(
                      left: x,
                      top: y,
                      child: Container(
                        width: 84,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 6),
                        decoration: BoxDecoration(
                          color: const Color(0xFF3B0E16),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: const Color(0xFFD4AF37)),
                        ),
                        child: Text(
                          '${i + 1}. ${state.players[i].name}',
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    );
                  }),
                ],
              );
            },
          ),
        ),
        _buildActionBtn(
          label: 'توزيع الأدوار',
          onTap: notifier.startRoleDistribution,
        ),
      ],
    );
  }

  Widget _buildRoleDistribution(MafiaGameState state, dynamic notifier) {
    final player = state.currentRoleDistributionPlayer;
    if (state.roleStep == RoleDistributionStep.handoff) {
      return _buildHandoffView(
        title: 'سلّم الجوال إلى',
        playerName: player.name,
        buttonLabel: 'أنا ${player.name}',
        onConfirm: () {
          setState(() => _hasRevealedCurrentRole = false);
          notifier.nextRoleDistribution();
        },
      );
    }

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          player.name,
          style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),
        HoldToRevealCard(
          roleInfo: player.roleInfo,
          onRevealedOnce: () {
            if (!_hasRevealedCurrentRole) {
              setState(() => _hasRevealedCurrentRole = true);
            }
          },
        ),
        const Spacer(),
        _buildActionBtn(
          label: 'فهمت، التالي',
          onTap: _hasRevealedCurrentRole ? notifier.nextRoleDistribution : null,
        ),
      ],
    );
  }

  Widget _buildNightAction(MafiaGameState state, dynamic notifier) {
    final currentPlayer = state.currentNightActionPlayer;

    if (!state.nightHandoffDone) {
      return _buildHandoffView(
        title: 'مرحلة الليل - أعطِ الجوال للاعب',
        playerName: currentPlayer.name,
        buttonLabel: 'أنا ${currentPlayer.name}',
        onConfirm: notifier.confirmNightHandoff,
      );
    }

    // شاشة نتيجة المحقق الفورية
    if (currentPlayer.role == MafiaRole.detective &&
        state.detectiveTarget != null) {
      final target =
          state.players.firstWhere((p) => p.id == state.detectiveTarget);
      final isMafia = state.detectiveResultIsMafia == true;
      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            isMafia ? Icons.warning_amber_rounded : Icons.verified_user_outlined,
            size: 84,
            color: isMafia ? Colors.redAccent : Colors.greenAccent,
          ),
          const SizedBox(height: 16),
          Text(
            target.name,
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            isMafia ? 'مافيا!' : 'ليس مافيا',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: isMafia ? Colors.redAccent : Colors.greenAccent,
            ),
          ),
          const Spacer(),
          _buildActionBtn(
            label: 'التالي',
            onTap: notifier.nextNightAction,
          ),
        ],
      );
    }

    // شاشة اختيار مهمة الجاسوس أو نتيجة التجسس
    if (currentPlayer.role == MafiaRole.spy) {
      if (state.spyChoseSpy == null) {
        return Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'اختر مهمتك الليلة',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            const Text(
              'لا يمكنك القتل والتجسس في نفس الليلة',
              style: TextStyle(color: Colors.white70),
            ),
            const SizedBox(height: 32),
            _buildActionBtn(
              label: 'تجسس (كشف دور لاعب)',
              onTap: () => notifier.setSpyMode(true),
            ),
            const SizedBox(height: 16),
            _buildActionBtn(
              label: 'المشاركة في القتل',
              onTap: () => notifier.setSpyMode(false),
            ),
          ],
        );
      }
      if (state.spyResultRole != null && state.spyTarget != null) {
        final target = state.players.firstWhere((p) => p.id == state.spyTarget);
        final roleInfo = MafiaRoleInfo.of(state.spyResultRole!);
        return Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(roleInfo.icon, size: 80, color: roleInfo.color),
            const SizedBox(height: 16),
            Text(
              target.name,
              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              'دوره الحقيقي: ${roleInfo.nameAr}',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: roleInfo.color,
              ),
            ),
            const Spacer(),
            _buildActionBtn(
              label: 'التالي',
              onTap: notifier.nextNightAction,
            ),
          ],
        );
      }
    }

    final isCitizenCover = currentPlayer.roleInfo.isCitizenBehaviorInNight ||
        (currentPlayer.role == MafiaRole.gambler && state.currentRound > 1);

    String promptText = 'اختر اسمك من القائمة كتمويه';
    if (currentPlayer.role == MafiaRole.mafia ||
        currentPlayer.role == MafiaRole.godfather ||
        (currentPlayer.role == MafiaRole.spy && state.spyChoseSpy == false)) {
      promptText = 'اختر لاعباً لقتله الليلة';
    } else if (currentPlayer.role == MafiaRole.doctor ||
        currentPlayer.role == MafiaRole.bodyguard) {
      promptText = 'اختر لاعباً لحمايته الليلة';
    } else if (currentPlayer.role == MafiaRole.detective) {
      promptText = 'اختر لاعباً للتحقيق عنه';
    } else if (currentPlayer.role == MafiaRole.spy &&
        state.spyChoseSpy == true) {
      promptText = 'اختر لاعباً للتجسس عليه';
    } else if (currentPlayer.role == MafiaRole.gambler &&
        state.currentRound == 1) {
      promptText = 'اختر لاعباً تراهن على إقصائه بالتصويت';
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '${currentPlayer.name} (${currentPlayer.roleInfo.nameAr})',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: currentPlayer.roleInfo.color,
          ),
        ),
        const SizedBox(height: 6),
        Text(promptText, style: const TextStyle(color: Colors.white70)),
        if (currentPlayer.isMafiaTeam && state.mafiaTargets.isNotEmpty) ...[
          const SizedBox(height: 6),
          Text(
            'المافيا الآخر اختار: ${state.players.firstWhere((p) => p.id == state.mafiaTargets.last).name}',
            style: const TextStyle(color: Colors.amberAccent, fontSize: 13),
          ),
        ],
        const SizedBox(height: 14),
        Expanded(
          child: ListView(
            children: state.alivePlayers.map((candidate) {
              bool disabled = false;
              String subtitle = '';

              if (isCitizenCover && candidate.id != currentPlayer.id) {
                disabled = true;
              }
              if (!isCitizenCover &&
                  currentPlayer.role != MafiaRole.doctor &&
                  candidate.id == currentPlayer.id) {
                disabled = true;
              }
              if (currentPlayer.role == MafiaRole.doctor &&
                  state.lastDoctorTarget == candidate.id) {
                disabled = true;
                subtitle = 'حميته في الليلة السابقة';
              }
              if (currentPlayer.role == MafiaRole.bodyguard &&
                  state.lastBodyguardTarget == candidate.id) {
                disabled = true;
                subtitle = 'حميته في الليلة السابقة';
              }

              return Card(
                color: disabled
                    ? const Color(0xFF16070A)
                    : const Color(0xFF280B11),
                child: ListTile(
                  enabled: !disabled,
                  title: Text(
                    candidate.name +
                        (candidate.id == currentPlayer.id ? ' (أنت)' : ''),
                  ),
                  subtitle: subtitle.isNotEmpty ? Text(subtitle) : null,
                  trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                  onTap: disabled
                      ? null
                      : () => notifier.performNightAction(candidate.id),
                ),
              );
            }).toList(),
          ),
        ),
        if (currentPlayer.isMafiaTeam && state.spyChoseSpy != true)
          _buildActionBtn(
            label: 'تخطي القتل',
            onTap: () => notifier.performNightAction(null),
          ),
      ],
    );
  }

  Widget _buildNightResults(MafiaGameState state, dynamic notifier) {
    final result = state.lastNightResult!;
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.wb_sunny_outlined, size: 76, color: Colors.amber),
        const SizedBox(height: 16),
        const Text(
          'نتائج الليلة',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 24),
        if (result.killedPlayers.isEmpty)
          const Text(
            'لم يُقتل أحد الليلة!',
            style: TextStyle(fontSize: 20, color: Colors.greenAccent),
          )
        else
          ...result.killedPlayers.map(
            (p) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Text(
                'تم قتل: ${p.name}',
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.redAccent,
                ),
              ),
            ),
          ),
        if (result.savedByDoctor.isNotEmpty)
          ...result.savedByDoctor.map(
            (p) => Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Text(
                '${p.name} نجا بفضل الدكتور!',
                style: const TextStyle(fontSize: 18, color: Colors.tealAccent),
              ),
            ),
          ),
        if (result.sacrificedBodyguard != null &&
            result.protectedByBodyguard != null)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Text(
              'الحارس ${result.sacrificedBodyguard!.name} ضحى بنفسه لحماية ${result.protectedByBodyguard!.name}!',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 17, color: Colors.amberAccent),
            ),
          ),
        const Spacer(),
        _buildActionBtn(
          label: 'بدء النقاش',
          onTap: notifier.continueAfterNight,
        ),
      ],
    );
  }

  Widget _buildDiscussion(MafiaGameState state, dynamic notifier) {
    return Column(
      children: [
        const Text(
          'مرحلة النقاش',
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        const Text(
          'ناقشوا فيما بينكم.. كل واحد يبرّئ نفسه!',
          style: TextStyle(color: Colors.white70),
        ),
        const SizedBox(height: 16),
        Expanded(
          child: ListView(
            children: state.alivePlayers
                .map(
                  (p) => Card(
                    color: const Color(0xFF230A0F),
                    child: ListTile(
                      leading: const Icon(Icons.person, color: Colors.white70),
                      title: Text(p.name),
                    ),
                  ),
                )
                .toList(),
          ),
        ),
        _buildActionBtn(
          label: 'ابدأ التصويت',
          onTap: () => notifier.startVoting(),
        ),
      ],
    );
  }

  Widget _buildVoting(MafiaGameState state, dynamic notifier) {
    final voter = state.currentVotingPlayer;
    if (!state.votingHandoffDone) {
      return _buildHandoffView(
        title: state.isRevote
            ? 'إعادة التصويت (تعادل) - سلّم الجوال إلى'
            : 'مرحلة التصويت - سلّم الجوال إلى',
        playerName: voter.name,
        buttonLabel: 'أنا ${voter.name}',
        onConfirm: notifier.confirmVotingHandoff,
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'تصويت: ${voter.name}',
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 6),
        Text(
          state.isRevote
              ? 'صوّت بين المتعادلين فقط'
              : 'اختر من تريد إقصاءه من اللعبة',
          style: const TextStyle(color: Colors.white70),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: ListView(
            children: state.votablePlayers
                .where((c) => c.id != voter.id)
                .map(
                  (candidate) => Card(
                    color: const Color(0xFF280B11),
                    child: ListTile(
                      title: Text(candidate.name),
                      trailing: const Icon(Icons.how_to_vote_outlined),
                      onTap: () => notifier.castVote(candidate.id),
                    ),
                  ),
                )
                .toList(),
          ),
        ),
        _buildActionBtn(
          label: 'تخطي التصويت',
          onTap: () => notifier.castVote(null),
        ),
      ],
    );
  }

  Widget _buildVoteResult(
    MafiaGameState state,
    dynamic settings,
    dynamic notifier,
  ) {
    final res = state.lastVoteResult!;
    final eliminated = res.eliminatedPlayer;

    return Column(
      children: [
        const Text(
          'نتيجة التصويت',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 18),
        if (res.wasSkipped)
          const Text(
            'تم تخطي التصويت! لم يتم إقصاء أحد',
            style: TextStyle(fontSize: 20, color: Colors.amberAccent),
          )
        else if (res.wasTie)
          const Text(
            'تعادل! لم يتم إقصاء أحد',
            style: TextStyle(fontSize: 20, color: Colors.amberAccent),
          )
        else if (eliminated != null) ...[
          Text(
            'تم إقصاء: ${eliminated.name}',
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.redAccent,
            ),
          ),
          if (settings.revealEliminatedRole) ...[
            const SizedBox(height: 8),
            Text(
              'دوره كان: ${eliminated.roleInfo.nameAr}',
              style: TextStyle(
                fontSize: 19,
                color: eliminated.roleInfo.color,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ],
        const SizedBox(height: 20),
        if (settings.showVoteDetails) ...[
          const Align(
            alignment: Alignment.centerRight,
            child: Text(
              'تفاصيل التصويت:',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: ListView(
              children: res.votesByVoterId.entries.map((e) {
                final voter =
                    state.players.firstWhere((p) => p.id == e.key).name;
                final voted = e.value == null
                    ? 'تخطي التصويت'
                    : state.players.firstWhere((p) => p.id == e.value).name;
                return ListTile(
                  dense: true,
                  title: Text('$voter ⬅️ $voted'),
                );
              }).toList(),
            ),
          ),
        ] else
          const Spacer(),
        _buildActionBtn(
          label: 'متابعة',
          onTap: notifier.continueAfterVote,
        ),
      ],
    );
  }

  Widget _buildHunterRevenge(MafiaGameState state, dynamic notifier) {
    final hunter =
        state.players.firstWhere((p) => p.id == state.hunterPlayerId);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'انتقام الصياد (${hunter.name})!',
          style: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.orangeAccent,
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'اختر لاعباً لإطلاق النار عليه وإقصائه معك قبل مغادرتك اللعبة:',
          style: TextStyle(color: Colors.white70),
        ),
        const SizedBox(height: 16),
        Expanded(
          child: ListView(
            children: state.alivePlayers
                .map(
                  (p) => Card(
                    color: const Color(0xFF331014),
                    child: ListTile(
                      title: Text(p.name),
                      trailing: const Icon(
                        Icons.gps_fixed_rounded,
                        color: Colors.orangeAccent,
                      ),
                      onTap: () => notifier.performHunterRevenge(p.id),
                    ),
                  ),
                )
                .toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildGameOver(MafiaGameState state) {
    String headline = '';
    if (state.jesterWon && state.winningJester != null) {
      headline = 'فاز المهرج (${state.winningJester!.name})!';
    } else if (state.winner == RoleTeam.citizens) {
      headline = 'فاز المواطنون!';
    } else if (state.winner == RoleTeam.mafia) {
      headline = 'فازت المافيا!';
    }

    return Stack(
      alignment: Alignment.topCenter,
      children: [
        ConfettiWidget(
          confettiController: _confettiController,
          blastDirectionality: BlastDirectionality.explosive,
          shouldLoop: false,
        ),
        Column(
          children: [
            const Icon(Icons.emoji_events_rounded,
                size: 76, color: Color(0xFFD4AF37)),
            const SizedBox(height: 12),
            Text(
              headline,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            ),
            if (state.gamblerWon && state.winningGambler != null) ...[
              const SizedBox(height: 8),
              Text(
                'المراهن (${state.winningGambler!.name}) فاز أيضاً برهانه!',
                style: const TextStyle(
                    fontSize: 18, color: Colors.purpleAccent),
              ),
            ],
            const SizedBox(height: 18),
            const Align(
              alignment: Alignment.centerRight,
              child: Text(
                'كشف جميع الأدوار:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView(
                children: state.players.map((p) {
                  return Card(
                    color: const Color(0xFF21090E),
                    child: ListTile(
                      leading: Icon(p.roleInfo.icon, color: p.roleInfo.color),
                      title: Text(p.name),
                      trailing: Text(
                        p.roleInfo.nameAr,
                        style: TextStyle(
                          color: p.roleInfo.color,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            _buildActionBtn(
              label: 'العودة للصفحة الرئيسية',
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildHandoffView({
    required String title,
    required String playerName,
    required String buttonLabel,
    required VoidCallback onConfirm,
  }) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.phone_android_rounded,
            size: 72, color: Color(0xFFD4AF37)),
        const SizedBox(height: 20),
        Text(
          title,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 18, color: Colors.white70),
        ),
        const SizedBox(height: 12),
        Text(
          playerName,
          style: const TextStyle(
            fontSize: 32,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        const Spacer(),
        _buildActionBtn(label: buttonLabel, onTap: onConfirm),
      ],
    );
  }

  Widget _buildActionBtn({
    required String label,
    required VoidCallback? onTap,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 54,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFD32F2F),
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
        onPressed: onTap,
        child: Text(
          label,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
