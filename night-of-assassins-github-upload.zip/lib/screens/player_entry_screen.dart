import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/app_providers.dart';
import '../widgets/gothic_background.dart';
import 'mafia_game_screen.dart';

class PlayerEntryScreen extends ConsumerStatefulWidget {
  const PlayerEntryScreen({super.key});

  @override
  ConsumerState<PlayerEntryScreen> createState() => _PlayerEntryScreenState();
}

class _PlayerEntryScreenState extends ConsumerState<PlayerEntryScreen> {
  late List<TextEditingController> _controllers;

  @override
  void initState() {
    super.initState();
    final count = ref.read(mafiaSettingsProvider).playerCount;
    final saved = ref.read(playerNamesProvider);
    _controllers = List.generate(count, (i) {
      final text = i < saved.length ? saved[i] : '';
      return TextEditingController(text: text);
    });
  }

  @override
  void dispose() {
    for (final c in _controllers) {
      c.dispose();
    }
    super.dispose();
  }

  void _startGame() {
    final names = _controllers.map((c) => c.text.trim()).toList();
    if (names.any((n) => n.isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('الرجاء إدخال أسماء جميع اللاعبين')),
      );
      return;
    }
    if (names.toSet().length != names.length) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('لا يمكن تكرار الأسماء')),
      );
      return;
    }

    ref.read(playerNamesProvider.notifier).saveNames(names);
    ref.read(mafiaGameProvider.notifier).initializeGame(names);

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const MafiaGameScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GothicBackground(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: const Text('أسماء اللاعبين'),
      ),
      child: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _controllers.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: TextField(
                    controller: _controllers[index],
                    decoration: InputDecoration(
                      labelText: 'لاعب ${index + 1}',
                      filled: true,
                      fillColor: const Color(0xFF21090E),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFD32F2F),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                onPressed: _startGame,
                child: const Text(
                  'ابدأ اللعبة',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
