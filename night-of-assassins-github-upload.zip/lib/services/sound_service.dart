import 'package:flutter/services.dart';

class SoundService {
  void playClick() {
    HapticFeedback.lightImpact();
    SystemSound.play(SystemSoundType.click);
  }

  void playSuccess() {
    HapticFeedback.mediumImpact();
  }

  void playEliminated() {
    HapticFeedback.heavyImpact();
  }
}
