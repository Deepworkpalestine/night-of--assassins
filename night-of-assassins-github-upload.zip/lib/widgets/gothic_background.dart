import 'package:flutter/material.dart';

class GothicBackground extends StatelessWidget {
  final Widget child;
  final PreferredSizeWidget? appBar;

  const GothicBackground({
    super.key,
    required this.child,
    this.appBar,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: appBar,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.3),
            radius: 1.2,
            colors: [
              Color(0xFF3B0A11),
              Color(0xFF160407),
              Color(0xFF090204),
            ],
          ),
        ),
        child: SafeArea(child: child),
      ),
    );
  }
}
