import 'package:flutter/material.dart';
import '../models/mafia_role.dart';

class HoldToRevealCard extends StatefulWidget {
  final MafiaRoleInfo roleInfo;
  final VoidCallback onRevealedOnce;

  const HoldToRevealCard({
    super.key,
    required this.roleInfo,
    required this.onRevealedOnce,
  });

  @override
  State<HoldToRevealCard> createState() => _HoldToRevealCardState();
}

class _HoldToRevealCardState extends State<HoldToRevealCard> {
  double _dragOffset = 0.0;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onVerticalDragUpdate: (details) {
        setState(() {
          _dragOffset = (_dragOffset - details.delta.dy).clamp(0.0, 260.0);
        });
        if (_dragOffset > 120) {
          widget.onRevealedOnce();
        }
      },
      onVerticalDragEnd: (_) {
        setState(() {
          _dragOffset = 0.0;
        });
      },
      child: SizedBox(
        width: 280,
        height: 390,
        child: Stack(
          alignment: Alignment.center,
          children: [
            // البطاقة الأمامية الكاشفة للدور
            Container(
              width: 270,
              height: 380,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFF1F0A0E),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: const Color(0xFFD4AF37),
                  width: 3,
                ),
                boxShadow: [
                  BoxShadow(
                    color: widget.roleInfo.color.withOpacity(0.35),
                    blurRadius: 24,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Align(
                    alignment: Alignment.topRight,
                    child: Text(
                      widget.roleInfo.cardLetter,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFD4AF37),
                      ),
                    ),
                  ),
                  const Spacer(),
                  CircleAvatar(
                    radius: 48,
                    backgroundColor: widget.roleInfo.color.withOpacity(0.2),
                    child: Icon(
                      widget.roleInfo.icon,
                      size: 54,
                      color: widget.roleInfo.color,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    widget.roleInfo.nameAr,
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: widget.roleInfo.color,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    widget.roleInfo.shortDesc,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 15,
                      color: Colors.white70,
                    ),
                  ),
                  const Spacer(),
                  Align(
                    alignment: Alignment.bottomLeft,
                    child: Text(
                      widget.roleInfo.cardLetter,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFD4AF37),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // غطاء البطاقة القوطي الذي ينسحب للأعلى
            Transform.translate(
              offset: Offset(0, -_dragOffset),
              child: Container(
                width: 274,
                height: 384,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFF4A0E17),
                      Color(0xFF1B0508),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: const Color(0xFFD4AF37),
                    width: 2.5,
                  ),
                ),
                child: const Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.shield_moon_outlined,
                      size: 72,
                      color: Color(0xFFD4AF37),
                    ),
                    SizedBox(height: 16),
                    Text(
                      'ليلة المغتالين',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFD4AF37),
                      ),
                    ),
                    SizedBox(height: 36),
                    Icon(
                      Icons.keyboard_double_arrow_up_rounded,
                      size: 36,
                      color: Colors.white70,
                    ),
                    SizedBox(height: 8),
                    Text(
                      'اسحب الكرت للأعلى لمعرفة دورك',
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
